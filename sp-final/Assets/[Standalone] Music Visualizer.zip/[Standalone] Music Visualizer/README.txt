  Unity  Music  Visualizer
				  Brian G.

/////////////////////////////////////////////////////////////////////////////////////
				INSTRUCTIONS
/////////////////////////////////////////////////////////////////////////////////////

	To start the visualizer, double click the MusicVisualizer.exe file.

	To start visualizing the sample song, press the space bar.

	To add more songs, simply make a .WAV copy of the song and add it 
	to the contents of this folder.
	(I use http://www.media.io/ for conversions)

	It is important that the songs and the data folder be kept in the 
	same directory as the executable file. 

	Songs in the folder are played at random - To skip a song, simply 
	press the spacebar again. 

	When all the songs have been played, you will need to close the 
	program and restart it to play them again.

/////////////////////////////////////////////////////////////////////////////////////

	I appologize for the rudimentary controls and functionality, 
	this is a small side project I do for fun. Thank you again 
	for supporting me and my education with your donations. 